import React, { useState } from "react";
import { registerPlugin } from "@capacitor/core";

const Apps = registerPlugin("Apps");
const BUILD_TAG = "18.08-T4";

// цвета (тёмная схема, как в отладке 4PDApps)
const C = {
  bg: "#0d0d0d", bar: "#161616", card: "#1b1b1b", input: "#222",
  border: "#333", divider: "#2a2a2a", text: "#e9e6e2", sub: "#9a8f82",
  acc: "#c8892e", onAcc: "#0d0d0d", off: "#3a3a3a", dbg: "#101010",
};

const PROTO_VER = "1.9.43";
const protoVer = () => localStorage.getItem("t4_proto_ver") || PROTO_VER;

// снять подсветку/BB-теги из ответов сервера поиска
function protoClean(s) {
  return String(s || "")
    .replace(/\u0002|\u0003/g, "")
    .replace(/\\u0002|\\u0003/g, "")
    .replace(/\[\/?(?:backgroud|background|color|size|b|i|u)[^\]]*\]/gi, "")
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(+n))
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCharCode(parseInt(n, 16)))
    .replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&nbsp;/g, " ")
    .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&")
    .trim();
}
function parseProtoSearch(raw) {
  const s = String(raw || "");
  let total = 0;
  const mt = s.match(/^\[\d+,0,(\d+),/);
  if (mt) total = parseInt(mt[1], 10);
  const items = [];
  const re = /\[\d+,(\d{3,9}),"((?:[^"\\]|\\.)*)","((?:[^"\\]|\\.)*)"/g;
  let m;
  while ((m = re.exec(s)) && items.length < 40) {
    items.push({ topicId: m[1], title: protoClean(m[2]), short: protoClean(m[3]) });
  }
  return { total, items };
}

export default function App() {
  const [pHost, setPHost] = useState(() => localStorage.getItem("t4_p_host") || "app.4pda.to");
  const [pPort, setPPort] = useState(() => localStorage.getItem("t4_p_port") || "993");
  const [pTls, setPTls] = useState(() => localStorage.getItem("t4_p_tls") === "1");
  const [pType, setPType] = useState(() => localStorage.getItem("t4_p_type") || "1");
  const [pZip, setPZip] = useState(() => localStorage.getItem("t4_p_zip") !== "0");
  const [pData, setPData] = useState(() => localStorage.getItem("t4_p_data") || "");
  const [pUser, setPUser] = useState(() => localStorage.getItem("t4_user") || "");
  const [pPass, setPPass] = useState(() => localStorage.getItem("t4_pass") || "");
  const [pUid, setPUid] = useState(() => localStorage.getItem("t4_uid") || "");
  const [pKey, setPKey] = useState(() => localStorage.getItem("t4_key") || "");
  const [pDl, setPDl] = useState(() => localStorage.getItem("t4_dl") || "");
  const [pLog, setPLog] = useState("");
  const [pBusy, setPBusy] = useState(false);

  const save = () => {
    try {
      localStorage.setItem("t4_p_host", pHost); localStorage.setItem("t4_p_port", pPort);
      localStorage.setItem("t4_p_tls", pTls ? "1" : "0"); localStorage.setItem("t4_p_type", pType);
      localStorage.setItem("t4_p_zip", pZip ? "1" : "0"); localStorage.setItem("t4_p_data", pData);
      localStorage.setItem("t4_user", pUser); localStorage.setItem("t4_pass", pPass);
      localStorage.setItem("t4_uid", pUid); localStorage.setItem("t4_key", pKey);
      localStorage.setItem("t4_dl", pDl);
    } catch {}
  };
  const err = (e) => "Не удалось: " + ((e && (e.message || e.errorMessage)) || "?");
  const idNum = (min) => (pData.match(new RegExp("\\d{" + min + ",12}")) || [])[0] || "";

  // сырой сокет: отправить текст/байты и показать ответ
  const probeSend = async () => {
    if (pBusy) return; setPBusy(true); setPLog("Подключаюсь…"); save();
    const isHex = /^[0-9a-fA-F\s]+$/.test(pData.trim()) && pData.replace(/[^0-9a-fA-F]/g, "").length >= 4;
    try {
      const r = await Apps.rawSocket({ host: pHost.trim(), port: parseInt(pPort, 10) || 443, tls: pTls, ...(isHex ? { hex: pData } : { text: pData }), waitMs: 6000, maxRead: 4096 });
      setPLog([
        `сервер: ${pHost}:${pPort}${pTls ? " (TLS)" : ""}`,
        r.ok ? `соединение: есть, ${r.ms} мс` : `ошибка: ${r.error || "?"} (${r.ms} мс)`,
        `отправлено байт: ${r.sent || 0}${isHex ? " (hex)" : " (текст)"}`,
        `получено байт: ${r.len || 0}`, "", "ТЕКСТ:", (r.text || "—"), "", "БАЙТЫ:", (r.hex || "—"),
      ].join("\n"));
    } catch (e) { setPLog(err(e)); }
    setPBusy(false);
  };
  // пакет ровно как у официального клиента (websocket-кадр)
  const probeFrame = async () => {
    if (pBusy) return; setPBusy(true); setPLog("Отправляю пакет…"); save();
    try {
      const r = await Apps.sendFrame({ host: pHost.trim(), port: parseInt(pPort, 10) || 443, tls: pTls, type: parseInt(pType, 10) || 0, compress: pZip, flag80: true, text: pData, waitMs: 6000 });
      setPLog([
        `пакет: тип ${pType}${pZip ? ", сжатый" : ""} → ${pHost}:${pPort}${pTls ? " TLS" : ""}`,
        `сервер поздоровался первым: ${r.helloLen || 0} байт${r.helloLen ? " · " + (r.helloText || "") : ""}`,
        r.ok ? `отправлено ${r.sent || 0}, ответ за ${r.ms} мс` : `ошибка: ${r.error || "?"}`,
        `получено байт: ${r.len || 0}`,
        (r.respLen != null ? `ответ: тип ${r.respType}, ${r.respCompressed ? "сжат" : "не сжат"}, длина ${r.respLen}` : ""),
        "", "СОДЕРЖИМОЕ:", (r.body || "—"), "", "ТЕКСТ:", (r.text || "—"), "", "БАЙТЫ:", (r.hex || "—"),
      ].filter((x) => x !== "").join("\n"));
    } catch (e) { setPLog(err(e)); }
    setPBusy(false);
  };
  // рукопожатие веб-сокета + пакет
  const probeWs = async () => {
    if (pBusy) return; setPBusy(true); setPLog("Здороваюсь…"); save();
    try {
      const r = await Apps.wsProbe({ host: pHost.trim(), port: parseInt(pPort, 10) || 443, path: "/ws/", tls: pTls, type: parseInt(pType, 10) || 1, compress: pZip, mask: false, text: pData, waitMs: 7000 });
      setPLog([
        `${pHost}:${pPort}/ws/ — ${r.upgraded ? "рукопожатие принято" : "рукопожатие НЕ принято"}${r.ok ? "" : " · ошибка: " + (r.error || "?")}`,
        "ответ на рукопожатие:", (r.handshake || "—").trim(),
        "", `отправлено ${r.sent || 0} · получено ${r.len || 0} · ${r.ms} мс`,
        "", "СОДЕРЖИМОЕ:", (r.body || "—"), "", "БАЙТЫ:", (r.hex || "—"),
      ].join("\n"));
    } catch (e) { setPLog(err(e)); }
    setPBusy(false);
  };
  // тема через служебный сервер (ah + fr)
  const probeTopic = async () => {
    if (pBusy) return; setPBusy(true); setPLog("Спрашиваю тему…"); save();
    const tid = idNum(4) || "1124379";
    try {
      const r = await Apps.protoTopic({ host: pHost.trim() || "app.4pda.to", port: parseInt(pPort, 10) || 993, topicId: tid, ver: protoVer(), waitMs: 9000 });
      setPLog([
        `тема ${tid} — ${r.ok ? "ответ получен" : "ошибка: " + (r.error || "?")} за ${r.ms} мс`,
        "", "ПРЕДСТАВЛЕНИЕ:", (r.hello || "—"),
        "", "ОТВЕТ ПРО ТЕМУ:", (r.topic || "—").slice(0, 4000),
      ].join("\n"));
    } catch (e) { setPLog(err(e)); }
    setPBusy(false);
  };
  // прямая ссылка на вложение (команда fa) — работает ли гостю без входа
  const probeLink = async () => {
    if (pBusy) return; setPBusy(true); setPLog("Спрашиваю ссылку на файл…"); save();
    const aid = idNum(5);
    if (!aid) { setPLog("Впиши в поле номер вложения (число)"); setPBusy(false); return; }
    try {
      const r = await Apps.protoAttach({ host: pHost.trim() || "app.4pda.to", port: parseInt(pPort, 10) || 993, attachIds: [aid], user: pUser.trim(), pass: pPass, ver: protoVer(), waitMs: 12000 });
      const l = (r && r.links) || [];
      setPLog([
        `вложение ${aid} — ${r.ok ? "ответ получен" : "ошибка: " + (r.error || "?")} за ${r.ms} мс`,
        (pUser.trim() && pPass ? "вход: выполнен (ml)" : "вход: без входа (гость)"),
        "", "ССЫЛКА:", (l[0] || "— сервер не дал ссылку"),
      ].join("\n"));
    } catch (e) { setPLog(err(e)); }
    setPBusy(false);
  };
  // файлы темы через App&Game getFileInfo — подпись/размер/ABI/crc БЕЗ скачивания и БЕЗ входа
  const probeFiles = async () => {
    if (pBusy) return; setPBusy(true); setPLog("Спрашиваю сведения о файлах у App&Game…"); save();
    const tid = idNum(4) || "318294";
    try {
      const r = await Apps.agRequest({ srv: 1, method: "getFileInfo.php", params: "", q: `topic_id=${tid}` });
      const out = [`тема ${tid} · getFileInfo.php · ${r.ok ? "код " + r.status : "ошибка " + (r.error || "?")} · ${r.ms} мс`, ""];
      let data = null;
      try { data = JSON.parse(r.body || "{}").data; } catch {}
      if (Array.isArray(data) && data.length) {
        out.push(`файлов: ${data.length}`, "");
        for (const f of data.slice(0, 20)) {
          out.push(
            `• ${f.app_name || ""} ${f.version_name || ""} (${f.version_code || "?"})`,
            `  пакет: ${f.pack_name || "—"}`,
            `  подпись: ${f.signature || "—"}`,
            `  размер: ${f.file_size || "?"} · скачиваний: ${f.downloads_count || "?"} · minSdk: ${f.min_sdk || "?"} · flags: ${f.flags || "?"} · crc32: ${f.crc32 || "?"}`,
            `  ${f.file_name || ""}`, ""
          );
        }
      } else {
        out.push("data нет. Сырой ответ:", (r.body || "—").slice(0, 1500));
      }
      setPLog(out.join("\n"));
    } catch (e) { setPLog(err(e)); }
    setPBusy(false);
  };
  // связи пакет→тема через App&Game getAppInfo (packages в адресе)
  const probeApp = async () => {
    if (pBusy) return; setPBusy(true); setPLog("Спрашиваю сведения о приложении…"); save();
    const pkg = (pData.trim().match(/[a-z][a-z0-9_]*(?:\.[a-z0-9_]+)+/i) || ["com.mixplorer"])[0];
    try {
      const r = await Apps.agRequest({ srv: 1, method: "getAppInfo.php", params: "", q: `packages=${encodeURIComponent(pkg)}` });
      const out = [`пакет ${pkg} · getAppInfo.php · ${r.ok ? "код " + r.status : "ошибка " + (r.error || "?")} · ${r.ms} мс`, ""];
      let data = null;
      try { data = JSON.parse(r.body || "{}").data; } catch {}
      if (Array.isArray(data) && data.length) {
        for (const a of data) out.push(
          `• ${a.name || ""}`, `  тема: ${a.topic_id} · версия: ${a.ver || "?"}`,
          `  раздел: ${a.group_name || "?"} · обновлено: ${a.forum_update || "?"}`,
          `  иконка: ${a.icon || "—"}`, ""
        );
      } else out.push("data нет. Сырой ответ:", (r.body || "—").slice(0, 1500));
      setPLog(out.join("\n"));
    } catch (e) { setPLog(err(e)); }
    setPBusy(false);
  };
  // поиск на служебном сервере (команда rc)
  const probeSearch = async () => {
    if (pBusy) return; setPBusy(true); setPLog("Ищу на служебном сервере…"); save();
    const q = (pData.trim() || "браузер");
    try {
      const r = await Apps.protoSearch({ host: "app.4pda.to", port: 993, query: q, from: 0, count: 20, flags: 196611, ver: protoVer(), waitMs: 12000 });
      const pr = parseProtoSearch((r && r.raw) || "");
      const out = [`запрос «${q}» — ${r.ok ? "ответ получен" : "ошибка: " + (r.error || "?")} за ${r.ms} мс`, `всего найдено: ${pr.total}`, ""];
      for (const it of pr.items.slice(0, 15)) out.push(`• ${it.title} (тема ${it.topicId})`);
      setPLog(out.join("\n"));
    } catch (e) { setPLog(err(e)); }
    setPBusy(false);
  };
  // Обход: 1) привязан ли ключ ?s= к конкретному файлу (берём ГОСТЕВОЙ ключ картинки и подставляем APK);
  //        2) отдаёт ли файл сайт гостю через endpoint картинок act=attach; 3) отдаёт ли CDN без ключа вовсе
  const probeBypass = async () => {
    if (pBusy) return; setPBusy(true); setPLog("Проверяю обходы раздачи…"); save();
    const m = pDl.match(/\/dl\/post\/(\d+)\/([^?\s]+)/);
    if (!m) { setPLog("Вставь в поле «ссылка dl» полную ссылку вида https://4pda.to/forum/dl/post/35985011/Имя.apk"); setPBusy(false); return; }
    const apkId = m[1], apkName = m[2];
    const imgId = "24164979"; // картинка из шапки MiXplorer — гостю fa её отдаёт
    const out = [`APK: ${apkId} / ${apkName}`, ""];
    try {
      // 1) гостевой ключ картинки
      const ri = await Apps.protoAttach({ host: "app.4pda.to", port: 993, attachIds: [imgId], ver: protoVer(), waitMs: 9000 });
      const imgUrl = (ri && ri.links && ri.links[0]) || "";
      out.push("гостевая ссылка картинки: " + (imgUrl || "нет — механизм проверить нельзя"));
      if (imgUrl) {
        const um = imgUrl.match(/^(https?:\/\/[^/]+)\/\d+\/[^?]+\?s=(.+)$/);
        if (um) {
          const origin = um[1], tok = um[2];
          const swap = `${origin}/${apkId}/${apkName}?s=${tok}`;
          out.push("", "[1] ключ картинки на URL APK:");
          const r1 = await Apps.httpProbe({ url: swap });
          out.push(`  статус ${r1.status} · ${r1.contentType || ""} · ${r1.len || ""} · байты ${r1.firstBytes || "—"} · ${r1.looksApk ? "✅ ЭТО APK" : "не apk"}`);
          if (r1.chain) out.push("  " + r1.chain.replace(/\n/g, "\n  ").trim());
          out.push("", "[3] CDN без ключа:");
          const r3 = await Apps.httpProbe({ url: `${origin}/${apkId}/${apkName}` });
          out.push(`  статус ${r3.status} · байты ${r3.firstBytes || "—"} · ${r3.looksApk ? "✅ ЭТО APK" : "не apk"}`);
        }
      }
      // 2) сайт через endpoint картинок
      out.push("", "[2] сайт act=attach (endpoint картинок) на APK, гость:");
      const r2 = await Apps.httpProbe({ url: `https://4pda.to/forum/index.php?act=attach&type=post&id=${apkId}` });
      out.push(`  статус ${r2.status} · ${r2.contentType || ""} · ${r2.len || ""} · байты ${r2.firstBytes || "—"} · ${r2.looksApk ? "✅ ЭТО APK" : "не apk"}`);
      if (r2.chain) out.push("  " + r2.chain.replace(/\n/g, "\n  ").trim());
      // 4) сама dl-ссылка гостю
      out.push("", "[4] /forum/dl/post/ гостю:");
      const r4 = await Apps.httpProbe({ url: pDl.trim() });
      out.push(`  статус ${r4.status} · ${r4.contentType || ""} · байты ${r4.firstBytes || "—"} · ${r4.looksApk ? "✅ ЭТО APK" : "не apk"}`);
      if (r4.chain) out.push("  " + r4.chain.replace(/\n/g, "\n  ").trim());
      setPLog(out.join("\n"));
    } catch (e) { setPLog(err(e)); }
    setPBusy(false);
  };
  // проверка «ворот»: на каком состоянии входа сервер отдаёт ссылку на APK
  const probeGate = async () => {
    if (pBusy) return; setPBusy(true); setPLog("Проверяю ворота выдачи ссылки на APK…"); save();
    const aid = idNum(5);
    if (!aid) { setPLog("Впиши в поле номер вложения APK (число)"); setPBusy(false); return; }
    try {
      const r = await Apps.gateTest({ host: "app.4pda.to", port: 993, uid: pUid.trim(), key: pKey.trim(), attachId: aid, ver: protoVer() });
      const out = [`вложение ${aid} · uid ${pUid.trim() || "—"} · ${r.ms} мс`, ""];
      for (const c of (r.combos || [])) {
        out.push(`${c.name}: ${c.link ? "✅ ССЫЛКА ЕСТЬ" : "нет"}`);
        if (c.link) out.push("  " + c.link);
        out.push("  " + (c.resp || ""));
        out.push("");
      }
      setPLog(out.join("\n"));
    } catch (e) { setPLog(err(e)); }
    setPBusy(false);
  };
  // вход логином/паролем через протокол (ml) — как официальный клиент, без капчи
  const probeLogin = async () => {
    if (pBusy) return; setPBusy(true); setPLog("Вхожу логином/паролем…"); save();
    if (!pUser.trim() || !pPass) { setPLog("Впиши логин и пароль от 4pda в поля выше"); setPBusy(false); return; }
    try {
      const r = await Apps.protoLogin({ host: "app.4pda.to", port: 993, user: pUser.trim(), pass: pPass, ver: protoVer() });
      setPLog([
        `вход — ${r.ok ? "ответ получен" : "ошибка: " + (r.error || "?")} за ${r.ms} мс`,
        "", "ПРЕДСТАВЛЕНИЕ:", (r.hello || "—"),
        "", "ОТВЕТ НА ВХОД (ml):", (r.login || "—").slice(0, 800),
        "", "ПРОФИЛЬ (ms):", (r.profile || "—").slice(0, 800),
      ].join("\n"));
    } catch (e) { setPLog(err(e)); }
    setPBusy(false);
  };
  // профиль (команда ms) — что отдаёт сервер про пользователя без входа
  const probeProfile = async () => {
    if (pBusy) return; setPBusy(true); setPLog("Спрашиваю профиль…"); save();
    try {
      const r = await Apps.protoProfile({ host: "app.4pda.to", port: 993, ver: protoVer() });
      const raw = String((r && r.raw) || "");
      setPLog([`ответ, длина ${raw.length}${r && r.error ? " · ошибка: " + r.error : ""}`, "", raw.slice(0, 1200)].join("\n"));
    } catch (e) { setPLog(err(e)); }
    setPBusy(false);
  };

  const Btn = ({ on, children }) => (
    <div onClick={on} style={{ background: pBusy ? C.off : C.acc, color: pBusy ? C.sub : C.onAcc, fontWeight: 700, fontSize: 13.5, padding: "9px 14px", borderRadius: 9, cursor: pBusy ? "default" : "pointer" }}>{pBusy ? "Жду…" : children}</div>
  );
  const inp = { background: C.input, border: `1px solid ${C.border}`, borderRadius: 8, color: C.text, fontSize: 13.5, padding: "9px 10px" };
  const copy = () => { try { navigator.clipboard.writeText(pLog); } catch {} };

  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column" }}>
      <div style={{ paddingTop: "var(--sat)", background: C.bar, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0 16px", height: 56 }}>
          <span style={{ color: C.text, fontSize: 20, fontWeight: 700 }}>4PDA Tester</span>
          <span style={{ color: C.sub, fontSize: 11, marginLeft: "auto" }}>сборка {BUILD_TAG}</span>
        </div>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: "14px 16px calc(var(--sab) + 24px)" }}>
        <div style={{ color: C.sub, fontSize: 12, marginBottom: 10, lineHeight: 1.4 }}>
          Пробник протокола 4pda (app.4pda.to:993, без TLS) и сервера App&Game. Кнопки «Файлы темы» и «Приложение» дают подпись/версию/ABI без скачивания и без входа.
        </div>

        <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
          <input value={pHost} onChange={(e) => setPHost(e.target.value)} placeholder="сервер" autoCapitalize="none" style={{ ...inp, flex: 2, minWidth: 0 }} />
          <input value={pPort} onChange={(e) => setPPort(e.target.value)} placeholder="порт" inputMode="numeric" style={{ ...inp, flex: 1, minWidth: 0 }} />
        </div>
        <div onClick={() => setPTls((v) => !v)} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer", marginBottom: 8 }}>
          <span style={{ color: C.sub, fontSize: 13.5 }}>Защищённое соединение (TLS)</span>
          <div style={{ width: 42, height: 24, borderRadius: 12, background: pTls ? C.acc : C.off, position: "relative" }}><div style={{ position: "absolute", top: 2, left: pTls ? 20 : 2, width: 20, height: 20, borderRadius: "50%", background: "#fff" }} /></div>
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 8 }}>
          <span style={{ color: C.sub, fontSize: 13.5 }}>Тип пакета</span>
          <input value={pType} onChange={(e) => setPType(e.target.value)} inputMode="numeric" style={{ ...inp, width: 56, padding: "7px 10px" }} />
          <span onClick={() => setPZip((v) => !v)} style={{ color: pZip ? C.acc : C.sub, fontSize: 13.5, cursor: "pointer", marginLeft: 6 }}>{pZip ? "со сжатием" : "без сжатия"}</span>
        </div>
        <textarea value={pData} onChange={(e) => setPData(e.target.value)} placeholder="номер темы / вложения / имя пакета / запрос / байты 5b 74 71 5d" style={{ ...inp, width: "100%", boxSizing: "border-box", height: 84, fontFamily: "monospace", fontSize: 13 }} />

        <div style={{ color: C.sub, fontSize: 12, margin: "12px 0 6px" }}>Вход 4pda (логин/пароль — хранятся только на этом телефоне, нужны, чтобы сервер отдал ссылку на APK):</div>
        <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
          <input value={pUser} onChange={(e) => setPUser(e.target.value)} placeholder="логин" autoCapitalize="none" autoCorrect="off" style={{ ...inp, flex: 1, minWidth: 0 }} />
          <input value={pPass} onChange={(e) => setPPass(e.target.value)} placeholder="пароль" type="password" autoCapitalize="none" autoCorrect="off" style={{ ...inp, flex: 1, minWidth: 0 }} />
        </div>

        <div style={{ color: C.sub, fontSize: 12, margin: "10px 0 6px" }}>Для проверки ворот (необязательно): твой номер uid и ключ входа из дампа. Кейсы B/C/D работают без ключа.</div>
        <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
          <input value={pUid} onChange={(e) => setPUid(e.target.value)} placeholder="uid (число)" inputMode="numeric" style={{ ...inp, flex: 1, minWidth: 0 }} />
          <input value={pKey} onChange={(e) => setPKey(e.target.value)} placeholder="login_key (необяз.)" autoCapitalize="none" autoCorrect="off" style={{ ...inp, flex: 1, minWidth: 0 }} />
        </div>

        <div style={{ color: C.sub, fontSize: 12, margin: "10px 0 6px" }}>Для теста обходов: вставь полную ссылку скачивания APK (её ты берёшь из официального приложения, вида …/dl/post/35985011/Имя.apk):</div>
        <input value={pDl} onChange={(e) => setPDl(e.target.value)} placeholder="https://4pda.to/forum/dl/post/…/…apk" autoCapitalize="none" autoCorrect="off" style={{ ...inp, width: "100%", boxSizing: "border-box", marginBottom: 8, fontSize: 12 }} />

        <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
          <Btn on={probeBypass}>Обход раздачи</Btn>
          <Btn on={probeGate}>Тест ворот APK</Btn>
          <Btn on={probeLogin}>Войти (ml)</Btn>
          <Btn on={probeTopic}>Спросить тему</Btn>
          <Btn on={probeFiles}>Файлы темы (подпись)</Btn>
          <Btn on={probeApp}>Приложение (пакет)</Btn>
          <Btn on={probeSearch}>Поиск</Btn>
          <Btn on={probeLink}>Ссылка на файл</Btn>
          <Btn on={probeProfile}>Профиль</Btn>
          <Btn on={probeWs}>Подключиться и отправить</Btn>
          <Btn on={probeFrame}>Отправить как клиент</Btn>
          <Btn on={probeSend}>Отправить (сырой)</Btn>
          <div onClick={() => { setPData(""); setPLog(""); }} style={{ border: `1px solid ${C.border}`, color: C.sub, fontSize: 13.5, padding: "9px 14px", borderRadius: 9, cursor: "pointer" }}>Очистить</div>
          {pLog ? <div onClick={copy} style={{ border: `1px solid ${C.border}`, color: C.acc, fontSize: 13.5, padding: "9px 14px", borderRadius: 9, cursor: "pointer" }}>Скопировать</div> : null}
        </div>

        {pLog ? <div style={{ marginTop: 12, background: C.dbg, color: C.text, fontSize: 11.5, fontFamily: "monospace", whiteSpace: "pre-wrap", wordBreak: "break-all", padding: "10px 12px", borderRadius: 8, border: `1px solid ${C.border}` }}>{pLog}</div> : null}
      </div>
    </div>
  );
}
