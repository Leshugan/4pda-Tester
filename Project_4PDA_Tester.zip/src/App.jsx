import React, { useState } from "react";
import { registerPlugin } from "@capacitor/core";

const Apps = registerPlugin("Apps");
const BUILD_TAG = "18.08-T1";

// цвета (тёмная схема, как в отладке 4PDApps)
const C = {
  bg: "#0d0d0d", bar: "#161616", card: "#1b1b1b", input: "#222",
  border: "#333", divider: "#2a2a2a", text: "#e9e6e2", sub: "#9a8f82",
  acc: "#c8892e", onAcc: "#0d0d0d", off: "#3a3a3a", dbg: "#101010",
};

const PROTO_VER = "1.9.43";
const protoVer = () => localStorage.getItem("t4_proto_ver") || PROTO_VER;

// снять подсветку/BB-теги из ответов сервера поиска
function protoClean(s) {
  return String(s || "")
    .replace(/\u0002|\u0003/g, "")
    .replace(/\\u0002|\\u0003/g, "")
    .replace(/\[\/?(?:backgroud|background|color|size|b|i|u)[^\]]*\]/gi, "")
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(+n))
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCharCode(parseInt(n, 16)))
    .replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&nbsp;/g, " ")
    .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&")
    .trim();
}
function parseProtoSearch(raw) {
  const s = String(raw || "");
  let total = 0;
  const mt = s.match(/^\[\d+,0,(\d+),/);
  if (mt) total = parseInt(mt[1], 10);
  const items = [];
  const re = /\[\d+,(\d{3,9}),"((?:[^"\\]|\\.)*)","((?:[^"\\]|\\.)*)"/g;
  let m;
  while ((m = re.exec(s)) && items.length < 40) {
    items.push({ topicId: m[1], title: protoClean(m[2]), short: protoClean(m[3]) });
  }
  return { total, items };
}

export default function App() {
  const [pHost, setPHost] = useState(() => localStorage.getItem("t4_p_host") || "app.4pda.to");
  const [pPort, setPPort] = useState(() => localStorage.getItem("t4_p_port") || "993");
  const [pTls, setPTls] = useState(() => localStorage.getItem("t4_p_tls") === "1");
  const [pType, setPType] = useState(() => localStorage.getItem("t4_p_type") || "1");
  const [pZip, setPZip] = useState(() => localStorage.getItem("t4_p_zip") !== "0");
  const [pData, setPData] = useState(() => localStorage.getItem("t4_p_data") || "");
  const [pLog, setPLog] = useState("");
  const [pBusy, setPBusy] = useState(false);

  const save = () => {
    try {
      localStorage.setItem("t4_p_host", pHost); localStorage.setItem("t4_p_port", pPort);
      localStorage.setItem("t4_p_tls", pTls ? "1" : "0"); localStorage.setItem("t4_p_type", pType);
      localStorage.setItem("t4_p_zip", pZip ? "1" : "0"); localStorage.setItem("t4_p_data", pData);
    } catch {}
  };
  const err = (e) => "Не удалось: " + ((e && (e.message || e.errorMessage)) || "?");
  const idNum = (min) => (pData.match(new RegExp("\\d{" + min + ",12}")) || [])[0] || "";

  // сырой сокет: отправить текст/байты и показать ответ
  const probeSend = async () => {
    if (pBusy) return; setPBusy(true); setPLog("Подключаюсь…"); save();
    const isHex = /^[0-9a-fA-F\s]+$/.test(pData.trim()) && pData.replace(/[^0-9a-fA-F]/g, "").length >= 4;
    try {
      const r = await Apps.rawSocket({ host: pHost.trim(), port: parseInt(pPort, 10) || 443, tls: pTls, ...(isHex ? { hex: pData } : { text: pData }), waitMs: 6000, maxRead: 4096 });
      setPLog([
        `сервер: ${pHost}:${pPort}${pTls ? " (TLS)" : ""}`,
        r.ok ? `соединение: есть, ${r.ms} мс` : `ошибка: ${r.error || "?"} (${r.ms} мс)`,
        `отправлено байт: ${r.sent || 0}${isHex ? " (hex)" : " (текст)"}`,
        `получено байт: ${r.len || 0}`, "", "ТЕКСТ:", (r.text || "—"), "", "БАЙТЫ:", (r.hex || "—"),
      ].join("\n"));
    } catch (e) { setPLog(err(e)); }
    setPBusy(false);
  };
  // пакет ровно как у официального клиента (websocket-кадр)
  const probeFrame = async () => {
    if (pBusy) return; setPBusy(true); setPLog("Отправляю пакет…"); save();
    try {
      const r = await Apps.sendFrame({ host: pHost.trim(), port: parseInt(pPort, 10) || 443, tls: pTls, type: parseInt(pType, 10) || 0, compress: pZip, flag80: true, text: pData, waitMs: 6000 });
      setPLog([
        `пакет: тип ${pType}${pZip ? ", сжатый" : ""} → ${pHost}:${pPort}${pTls ? " TLS" : ""}`,
        `сервер поздоровался первым: ${r.helloLen || 0} байт${r.helloLen ? " · " + (r.helloText || "") : ""}`,
        r.ok ? `отправлено ${r.sent || 0}, ответ за ${r.ms} мс` : `ошибка: ${r.error || "?"}`,
        `получено байт: ${r.len || 0}`,
        (r.respLen != null ? `ответ: тип ${r.respType}, ${r.respCompressed ? "сжат" : "не сжат"}, длина ${r.respLen}` : ""),
        "", "СОДЕРЖИМОЕ:", (r.body || "—"), "", "ТЕКСТ:", (r.text || "—"), "", "БАЙТЫ:", (r.hex || "—"),
      ].filter((x) => x !== "").join("\n"));
    } catch (e) { setPLog(err(e)); }
    setPBusy(false);
  };
  // рукопожатие веб-сокета + пакет
  const probeWs = async () => {
    if (pBusy) return; setPBusy(true); setPLog("Здороваюсь…"); save();
    try {
      const r = await Apps.wsProbe({ host: pHost.trim(), port: parseInt(pPort, 10) || 443, path: "/ws/", tls: pTls, type: parseInt(pType, 10) || 1, compress: pZip, mask: false, text: pData, waitMs: 7000 });
      setPLog([
        `${pHost}:${pPort}/ws/ — ${r.upgraded ? "рукопожатие принято" : "рукопожатие НЕ принято"}${r.ok ? "" : " · ошибка: " + (r.error || "?")}`,
        "ответ на рукопожатие:", (r.handshake || "—").trim(),
        "", `отправлено ${r.sent || 0} · получено ${r.len || 0} · ${r.ms} мс`,
        "", "СОДЕРЖИМОЕ:", (r.body || "—"), "", "БАЙТЫ:", (r.hex || "—"),
      ].join("\n"));
    } catch (e) { setPLog(err(e)); }
    setPBusy(false);
  };
  // тема через служебный сервер (ah + fr)
  const probeTopic = async () => {
    if (pBusy) return; setPBusy(true); setPLog("Спрашиваю тему…"); save();
    const tid = idNum(4) || "1124379";
    try {
      const r = await Apps.protoTopic({ host: pHost.trim() || "app.4pda.to", port: parseInt(pPort, 10) || 993, topicId: tid, ver: protoVer(), waitMs: 9000 });
      setPLog([
        `тема ${tid} — ${r.ok ? "ответ получен" : "ошибка: " + (r.error || "?")} за ${r.ms} мс`,
        "", "ПРЕДСТАВЛЕНИЕ:", (r.hello || "—"),
        "", "ОТВЕТ ПРО ТЕМУ:", (r.topic || "—").slice(0, 4000),
      ].join("\n"));
    } catch (e) { setPLog(err(e)); }
    setPBusy(false);
  };
  // прямая ссылка на вложение (команда fa) — работает ли гостю без входа
  const probeLink = async () => {
    if (pBusy) return; setPBusy(true); setPLog("Спрашиваю ссылку на файл…"); save();
    const aid = idNum(5);
    if (!aid) { setPLog("Впиши в поле номер вложения (число)"); setPBusy(false); return; }
    try {
      const r = await Apps.protoAttach({ host: pHost.trim() || "app.4pda.to", port: parseInt(pPort, 10) || 993, attachIds: [aid], ver: protoVer(), waitMs: 9000 });
      const l = (r && r.links) || [];
      setPLog([
        `вложение ${aid} — ${r.ok ? "ответ получен" : "ошибка: " + (r.error || "?")} за ${r.ms} мс`,
        "", "ССЫЛКА:", (l[0] || "— сервер не дал ссылку (вероятно, нужен вход командой ma)"),
      ].join("\n"));
    } catch (e) { setPLog(err(e)); }
    setPBusy(false);
  };
  // файлы темы через App&Game getFileInfo — подпись/размер/ABI/crc БЕЗ скачивания и БЕЗ входа
  const probeFiles = async () => {
    if (pBusy) return; setPBusy(true); setPLog("Спрашиваю сведения о файлах у App&Game…"); save();
    const tid = idNum(4) || "318294";
    try {
      const r = await Apps.agRequest({ srv: 1, method: "getFileInfo.php", params: "", q: `topic_id=${tid}` });
      const out = [`тема ${tid} · getFileInfo.php · ${r.ok ? "код " + r.status : "ошибка " + (r.error || "?")} · ${r.ms} мс`, ""];
      let data = null;
      try { data = JSON.parse(r.body || "{}").data; } catch {}
      if (Array.isArray(data) && data.length) {
        out.push(`файлов: ${data.length}`, "");
        for (const f of data.slice(0, 20)) {
          out.push(
            `• ${f.app_name || ""} ${f.version_name || ""} (${f.version_code || "?"})`,
            `  пакет: ${f.pack_name || "—"}`,
            `  подпись: ${f.signature || "—"}`,
            `  размер: ${f.file_size || "?"} · скачиваний: ${f.downloads_count || "?"} · minSdk: ${f.min_sdk || "?"} · flags: ${f.flags || "?"} · crc32: ${f.crc32 || "?"}`,
            `  ${f.file_name || ""}`, ""
          );
        }
      } else {
        out.push("data нет. Сырой ответ:", (r.body || "—").slice(0, 1500));
      }
      setPLog(out.join("\n"));
    } catch (e) { setPLog(err(e)); }
    setPBusy(false);
  };
  // связи пакет→тема через App&Game getAppInfo (packages в адресе)
  const probeApp = async () => {
    if (pBusy) return; setPBusy(true); setPLog("Спрашиваю сведения о приложении…"); save();
    const pkg = (pData.trim().match(/[a-z][a-z0-9_]*(?:\.[a-z0-9_]+)+/i) || ["com.mixplorer"])[0];
    try {
      const r = await Apps.agRequest({ srv: 1, method: "getAppInfo.php", params: "", q: `packages=${encodeURIComponent(pkg)}` });
      const out = [`пакет ${pkg} · getAppInfo.php · ${r.ok ? "код " + r.status : "ошибка " + (r.error || "?")} · ${r.ms} мс`, ""];
      let data = null;
      try { data = JSON.parse(r.body || "{}").data; } catch {}
      if (Array.isArray(data) && data.length) {
        for (const a of data) out.push(
          `• ${a.name || ""}`, `  тема: ${a.topic_id} · версия: ${a.ver || "?"}`,
          `  раздел: ${a.group_name || "?"} · обновлено: ${a.forum_update || "?"}`,
          `  иконка: ${a.icon || "—"}`, ""
        );
      } else out.push("data нет. Сырой ответ:", (r.body || "—").slice(0, 1500));
      setPLog(out.join("\n"));
    } catch (e) { setPLog(err(e)); }
    setPBusy(false);
  };
  // поиск на служебном сервере (команда rc)
  const probeSearch = async () => {
    if (pBusy) return; setPBusy(true); setPLog("Ищу на служебном сервере…"); save();
    const q = (pData.trim() || "браузер");
    try {
      const r = await Apps.protoSearch({ host: "app.4pda.to", port: 993, query: q, from: 0, count: 20, flags: 196611, ver: protoVer(), waitMs: 12000 });
      const pr = parseProtoSearch((r && r.raw) || "");
      const out = [`запрос «${q}» — ${r.ok ? "ответ получен" : "ошибка: " + (r.error || "?")} за ${r.ms} мс`, `всего найдено: ${pr.total}`, ""];
      for (const it of pr.items.slice(0, 15)) out.push(`• ${it.title} (тема ${it.topicId})`);
      setPLog(out.join("\n"));
    } catch (e) { setPLog(err(e)); }
    setPBusy(false);
  };
  // профиль (команда ms) — что отдаёт сервер про пользователя без входа
  const probeProfile = async () => {
    if (pBusy) return; setPBusy(true); setPLog("Спрашиваю профиль…"); save();
    try {
      const r = await Apps.protoProfile({ host: "app.4pda.to", port: 993, ver: protoVer() });
      const raw = String((r && r.raw) || "");
      setPLog([`ответ, длина ${raw.length}${r && r.error ? " · ошибка: " + r.error : ""}`, "", raw.slice(0, 1200)].join("\n"));
    } catch (e) { setPLog(err(e)); }
    setPBusy(false);
  };

  const Btn = ({ on, children }) => (
    <div onClick={on} style={{ background: pBusy ? C.off : C.acc, color: pBusy ? C.sub : C.onAcc, fontWeight: 700, fontSize: 13.5, padding: "9px 14px", borderRadius: 9, cursor: pBusy ? "default" : "pointer" }}>{pBusy ? "Жду…" : children}</div>
  );
  const inp = { background: C.input, border: `1px solid ${C.border}`, borderRadius: 8, color: C.text, fontSize: 13.5, padding: "9px 10px" };
  const copy = () => { try { navigator.clipboard.writeText(pLog); } catch {} };

  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column" }}>
      <div style={{ paddingTop: "var(--sat)", background: C.bar, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0 16px", height: 56 }}>
          <span style={{ color: C.text, fontSize: 20, fontWeight: 700 }}>4PDA Tester</span>
          <span style={{ color: C.sub, fontSize: 11, marginLeft: "auto" }}>сборка {BUILD_TAG}</span>
        </div>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: "14px 16px calc(var(--sab) + 24px)" }}>
        <div style={{ color: C.sub, fontSize: 12, marginBottom: 10, lineHeight: 1.4 }}>
          Пробник протокола 4pda (app.4pda.to:993, без TLS) и сервера App&Game. Кнопки «Файлы темы» и «Приложение» дают подпись/версию/ABI без скачивания и без входа.
        </div>

        <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
          <input value={pHost} onChange={(e) => setPHost(e.target.value)} placeholder="сервер" autoCapitalize="none" style={{ ...inp, flex: 2, minWidth: 0 }} />
          <input value={pPort} onChange={(e) => setPPort(e.target.value)} placeholder="порт" inputMode="numeric" style={{ ...inp, flex: 1, minWidth: 0 }} />
        </div>
        <div onClick={() => setPTls((v) => !v)} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer", marginBottom: 8 }}>
          <span style={{ color: C.sub, fontSize: 13.5 }}>Защищённое соединение (TLS)</span>
          <div style={{ width: 42, height: 24, borderRadius: 12, background: pTls ? C.acc : C.off, position: "relative" }}><div style={{ position: "absolute", top: 2, left: pTls ? 20 : 2, width: 20, height: 20, borderRadius: "50%", background: "#fff" }} /></div>
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 8 }}>
          <span style={{ color: C.sub, fontSize: 13.5 }}>Тип пакета</span>
          <input value={pType} onChange={(e) => setPType(e.target.value)} inputMode="numeric" style={{ ...inp, width: 56, padding: "7px 10px" }} />
          <span onClick={() => setPZip((v) => !v)} style={{ color: pZip ? C.acc : C.sub, fontSize: 13.5, cursor: "pointer", marginLeft: 6 }}>{pZip ? "со сжатием" : "без сжатия"}</span>
        </div>
        <textarea value={pData} onChange={(e) => setPData(e.target.value)} placeholder="номер темы / вложения / имя пакета / запрос / байты 5b 74 71 5d" style={{ ...inp, width: "100%", boxSizing: "border-box", height: 84, fontFamily: "monospace", fontSize: 13 }} />

        <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
          <Btn on={probeTopic}>Спросить тему</Btn>
          <Btn on={probeFiles}>Файлы темы (подпись)</Btn>
          <Btn on={probeApp}>Приложение (пакет)</Btn>
          <Btn on={probeSearch}>Поиск</Btn>
          <Btn on={probeLink}>Ссылка на файл</Btn>
          <Btn on={probeProfile}>Профиль</Btn>
          <Btn on={probeWs}>Подключиться и отправить</Btn>
          <Btn on={probeFrame}>Отправить как клиент</Btn>
          <Btn on={probeSend}>Отправить (сырой)</Btn>
          <div onClick={() => { setPData(""); setPLog(""); }} style={{ border: `1px solid ${C.border}`, color: C.sub, fontSize: 13.5, padding: "9px 14px", borderRadius: 9, cursor: "pointer" }}>Очистить</div>
          {pLog ? <div onClick={copy} style={{ border: `1px solid ${C.border}`, color: C.acc, fontSize: 13.5, padding: "9px 14px", borderRadius: 9, cursor: "pointer" }}>Скопировать</div> : null}
        </div>

        {pLog ? <div style={{ marginTop: 12, background: C.dbg, color: C.text, fontSize: 11.5, fontFamily: "monospace", whiteSpace: "pre-wrap", wordBreak: "break-all", padding: "10px 12px", borderRadius: 8, border: `1px solid ${C.border}` }}>{pLog}</div> : null}
      </div>
    </div>
  );
}
