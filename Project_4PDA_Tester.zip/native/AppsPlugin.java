package leshugan.fuck4pda;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Environment;
import android.util.Base64;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.List;

// 4PDA Tester — пробник протокола 4pda и сервера App&Game (только отладка, взято из 4PDApps)
@CapacitorPlugin(name = "Apps")
public class AppsPlugin extends Plugin {

    private static final String UA = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";

    // ===== apkMeta =====
    @PluginMethod
    public void apkMeta(PluginCall call) {
        String path = call.getString("path");
        JSObject o = new JSObject();
        try {
            if (path == null || path.isEmpty()) { call.resolve(o); return; }
            File f = new File(path);
            if (!f.exists()) { try { File alt = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), f.getName()); if (alt.exists()) f = alt; } catch (Exception ignored) {} }
            if (!f.exists()) { call.resolve(o); return; }
            android.content.pm.PackageManager pm = getContext().getPackageManager();
            android.content.pm.PackageInfo pi = pm.getPackageArchiveInfo(f.getAbsolutePath(), 0);
            if (pi != null && pi.applicationInfo != null) {
                ApplicationInfo ai = pi.applicationInfo;
                ai.sourceDir = f.getAbsolutePath(); ai.publicSourceDir = f.getAbsolutePath();
                try { o.put("label", String.valueOf(ai.loadLabel(pm))); } catch (Exception ignored) {}
                try { o.put("version", pi.versionName); } catch (Exception ignored) {}
                try { o.put("pkg", pi.packageName); } catch (Exception ignored) {}
                try { String b64 = drawableToBase64(ai.loadIcon(pm)); if (b64 != null) o.put("icon", b64); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
        call.resolve(o);
    }

    // ===== deviceAbis =====
    @PluginMethod
    public void deviceAbis(PluginCall call) {        JSArray arr = new JSArray();
        try {
            String[] abis = (Build.VERSION.SDK_INT >= 21) ? Build.SUPPORTED_ABIS : new String[]{ Build.CPU_ABI };
            if (abis != null) for (String a : abis) arr.put(a);
        } catch (Exception ignored) {}
        JSObject ret = new JSObject();
        ret.put("abis", arr);
        call.resolve(ret);
    }

    // ===== protoAttach =====
    // Прямая ссылка на вложение по его номеру (команда fa) — сервер отдаёт готовый адрес с ключом,
    // качать можно без входа на сайт. И список постов темы (fr со смещением) — из них берём вложения.
    @PluginMethod
    public void protoAttach(final PluginCall call) {
        final String host = call.getString("host", "app.4pda.to");
        final int port = call.getInt("port", 993);
        final String ver = call.getString("ver", "1.9.43");
        final JSArray idsArr = call.getArray("attachIds");
        final String topicId = call.getString("topicId", "");
        final int from = call.getInt("from", 0);
        final int count = call.getInt("count", 20);
        final int waitMs = call.getInt("waitMs", 12000);
        new Thread(new Runnable() { public void run() {
            java.net.Socket sock = null; JSObject o = new JSObject(); long t0 = System.currentTimeMillis();
            JSArray links = new JSArray();
            try {
                sock = new java.net.Socket();
                sock.connect(new java.net.InetSocketAddress(host, port), 8000);
                sock.setSoTimeout(6000);
                java.io.OutputStream os = sock.getOutputStream();
                java.io.InputStream is = sock.getInputStream();
                int num = 1000 + (int) (Math.random() * 100000);
                os.write(protoFrame("[" + (num++) + ",\"ah\",\"" + ver + "\",\"\",\"\",0,0]")); os.flush();
                protoRead(is, 2000);
                if (topicId != null && !topicId.isEmpty()) {
                    boolean last = Boolean.TRUE.equals(call.getBoolean("last", Boolean.FALSE));
                    int off = from;
                    if (last) {   // файлы лежат в ПОСЛЕДНИХ постах: сперва узнаём, сколько их всего
                        os.write(protoFrame("[" + (num++) + ",\"fr\"," + topicId + ",0,1,0]")); os.flush();
                        String head = protoRead(is, 6000);
                        try {
                            java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\[\\],(\\d{1,7}),\\[\\[").matcher(head);
                            if (m.find()) { int total = Integer.parseInt(m.group(1)); off = Math.max(0, total - count); }
                        } catch (Exception ignored) {}
                        o.put("total", off);
                    }
                    os.write(protoFrame("[" + (num++) + ",\"fr\"," + topicId + "," + off + "," + count + ",0]")); os.flush();
                    o.put("posts", protoRead(is, waitMs));
                }
                java.util.List<String> ids = new java.util.ArrayList<>();
                try { java.util.List<Object> l = idsArr != null ? idsArr.toList() : null; if (l != null) for (Object x : l) { String v = String.valueOf(x); if (v.matches("\\d{3,12}")) ids.add(v); } } catch (Exception ignored) {}
                for (String id : ids) {
                    os.write(protoFrame("[" + (num++) + ",\"fa\"," + id + "]"));
                }
                if (!ids.isEmpty()) {
                    os.flush();
                    String r = protoRead(is, waitMs);
                    for (String line : r.split("\n")) {
                        int q = line.indexOf("\"http");
                        if (q > 0) {
                            int e = line.indexOf('"', q + 1);
                            if (e > q) { links.put(line.substring(q + 1, e)); }
                        }
                    }
                }
                o.put("ok", true);
            } catch (Throwable e) {
                o.put("ok", false); o.put("error", e.getClass().getSimpleName() + ": " + e.getMessage());
            } finally { try { if (sock != null) sock.close(); } catch (Exception ignored) {} }
            o.put("links", links); o.put("ms", System.currentTimeMillis() - t0);
            call.resolve(o);
        } }).start();
    }

    // ===== agRequest =====
    // ---- Сервер App&Game 4PDA (freeman42) как ДОПОЛНИТЕЛЬНЫЙ источник ----
    // Обычный POST на srv<N>.freeman42.ru/app4pda.v3/<метод>. Ключ — идентификатор устройства
    // (свой, генерируем один раз), «хеш» — его отпечаток MD5, как в их приложении.
    @PluginMethod
    public void agRequest(final PluginCall call) {
        final int srv = call.getInt("srv", 1);
        final String method = call.getString("method", "getAppInfo.php");
        final String extra = call.getString("params", "");     // готовая строка вида app_url=…&topic_id=…
        final String appVer = call.getString("appVer", "5.3 beta 9 (539)");   // ВАЖНО: без кода сборки в скобках сервер падает
        new Thread(new Runnable() { public void run() {
            JSObject o = new JSObject(); long t0 = System.currentTimeMillis();
            java.net.HttpURLConnection c = null;
            try {
                android.content.SharedPreferences sp = getContext().getSharedPreferences("t4ag", Context.MODE_PRIVATE);
                String raw = sp.getString("raw", "");
                if (raw.isEmpty()) {   // базовая строка идентификатора — РОВНО как q() в ag4pda, иначе сервер не подтвердит ключ и вернёт пусто
                    raw = agIdBase();
                    if (raw == null || raw.isEmpty()) raw = "ID|" + Long.toHexString(System.currentTimeMillis());
                    sp.edit().putString("raw", raw).apply();
                }
                // ключ = перевёрнутый base64 исходного идентификатора, отпечаток = MD5 ИСХОДНОГО (а не ключа)
                String key = new StringBuffer(Base64.encodeToString(raw.getBytes("UTF-8"), Base64.NO_WRAP)).reverse().toString();
                String hash = md5hex(raw);
                // как в их приложении: ключ/отпечаток/версия — В АДРЕСЕ, длинные значения (список тем) — в теле
                StringBuilder q = new StringBuilder();
                q.append("?key=").append(java.net.URLEncoder.encode(key, "UTF-8"));
                q.append("&hash=").append(java.net.URLEncoder.encode(hash, "UTF-8"));
                q.append("&app_ver=").append(java.net.URLEncoder.encode(appVer, "UTF-8"));
                // поля пользователя 4pda — их клиент шлёт их только когда человек вошёл; шлём, если заданы
                String uid = call.getString("userId", "");
                String uname = call.getString("userName", "");
                String emailHash = call.getString("emailHash", "");
                if (!uid.isEmpty()) q.append("&user_id=").append(java.net.URLEncoder.encode(uid, "UTF-8"));
                if (!uname.isEmpty()) q.append("&username=").append(java.net.URLEncoder.encode(uname, "UTF-8"));
                if (!emailHash.isEmpty()) q.append("&email_hash=").append(java.net.URLEncoder.encode(emailHash, "UTF-8"));
                String extraQ = call.getString("q", "");            // произвольные дополнительные поля адреса (для подбора)
                if (extraQ.equals("device_key=")) extraQ = "device_key=" + java.net.URLEncoder.encode(key, "UTF-8");   // их «ключ устройства» = наш key
                if (!extraQ.isEmpty()) q.append("&").append(extraQ);
                // ПУСТЫЕ username/email_hash НЕ шлём: сервер подставляет их в запрос к базе как есть и падает
                // сведения об устройстве сервер записывает у себя — без них падает на вставке в базу
                // ВАЖНО: сведения об устройстве у них — 13 полей через «|», сервер разбирает их по частям.
                // Пустые части ломают его запрос к базе, поэтому заполняем все.
                String aid = "";
                try { aid = android.provider.Settings.Secure.getString(getContext().getContentResolver(), android.provider.Settings.Secure.ANDROID_ID); } catch (Throwable ignored) {}
                if (aid == null || aid.isEmpty()) aid = "0000000000000000";
                String btAddr = "";
                try { btAddr = android.provider.Settings.Secure.getString(getContext().getContentResolver(), "bluetooth_address"); } catch (Throwable ignored) {}
                String serial = "";
                try { serial = android.os.Build.SERIAL; } catch (Throwable ignored) {}
                if ("unknown".equals(serial)) serial = "";
                int buildHc = 0;
                try { buildHc = android.os.Build.BOARD.hashCode() + android.os.Build.BRAND.hashCode() + android.os.Build.CPU_ABI.hashCode() + android.os.Build.DEVICE.hashCode() + android.os.Build.DISPLAY.hashCode() + android.os.Build.HOST.hashCode() + android.os.Build.ID.hashCode() + android.os.Build.MANUFACTURER.hashCode() + android.os.Build.MODEL.hashCode() + android.os.Build.PRODUCT.hashCode() + android.os.Build.TAGS.hashCode() + android.os.Build.TYPE.hashCode() + android.os.Build.USER.hashCode(); } catch (Throwable ignored) {}
                // 13 полей device_info в порядке ag4pda; пустые допустимы (их клиент тоже шлёт пустыми), сервер разбирает по индексам
                String[] parts = new String[] {
                    "",                                        // [0] IMEI (не запрашиваем — как на телефонах без разрешения)
                    "",                                        // [1] wifi mac (на 6.0+ система отдаёт 02:00:.. — их клиент тоже получает пусто)
                    btAddr == null ? "" : btAddr,              // [2] bluetooth address
                    String.valueOf(buildHc),                   // [3] сумма hashCode полей Build
                    serial == null ? "" : serial,              // [4] serial
                    aid,                                       // [5] android_id
                    agUuid(),                                  // [6] стойкий UUID (persisted)
                    agModelName(),                             // [7] "Производитель Модель"
                    android.os.Build.VERSION.RELEASE,          // [8] версия Android
                    java.util.Locale.getDefault().toString(),  // [9] локаль
                    String.valueOf(android.os.Build.VERSION.SDK_INT), // [10] API
                    String.valueOf(agAbiMask()),               // [11] битовая маска ABI
                    String.valueOf(agTzMinutes())              // [12] смещение часового пояса в минутах
                };
                StringBuilder db = new StringBuilder();
                for (int i = 0; i < parts.length; i++) {
                    if (i > 0) db.append("|");
                    db.append(parts[i] == null ? "" : parts[i]);
                }
                String dev = db.toString();
                StringBuilder body = new StringBuilder();
                body.append("device_info=").append(java.net.URLEncoder.encode(dev, "UTF-8"));
                if (extra != null && !extra.isEmpty()) body.append("&").append(extra);
                java.net.URL u = new java.net.URL("https://srv" + srv + ".freeman42.ru/app4pda.v3/" + method + q);
                c = (java.net.HttpURLConnection) u.openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(8000); c.setReadTimeout(12000);
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                c.setRequestProperty("User-Agent", UA);
                c.setDoOutput(true);
                byte[] bb = body.toString().getBytes("UTF-8");
                c.getOutputStream().write(bb); c.getOutputStream().flush();
                int code = c.getResponseCode();
                java.io.InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
                java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[8192]; int n;
                while ((n = is.read(buf)) > 0 && bos.size() < 12 * 1024 * 1024) bos.write(buf, 0, n);   // ответы по темам с сотнями файлов бывают в несколько мегабайт
                o.put("status", code);
                o.put("sent", u.toString() + "  |  тело: " + body.toString());
                o.put("body", new String(bos.toByteArray(), "UTF-8"));
                o.put("ok", true);
            } catch (Throwable e) {
                o.put("ok", false); o.put("error", e.getClass().getSimpleName() + ": " + e.getMessage());
            } finally { try { if (c != null) c.disconnect(); } catch (Exception ignored) {} }
            o.put("ms", System.currentTimeMillis() - t0);
            call.resolve(o);
        } }).start();
    }

    // ===== protoProfile =====
    // Профиль пользователя через служебный сервер: имя, репутация и ссылка на аватар
    @PluginMethod
    public void protoProfile(final PluginCall call) {
        final String host = call.getString("host", "app.4pda.to");
        final int port = call.getInt("port", 993);
        final String ver = call.getString("ver", "1.9.43");
        new Thread(new Runnable() { public void run() {
            java.net.Socket sock = null; JSObject o = new JSObject();
            try {
                sock = new java.net.Socket();
                sock.connect(new java.net.InetSocketAddress(host, port), 8000);
                sock.setSoTimeout(6000);
                java.io.OutputStream os = sock.getOutputStream();
                java.io.InputStream is = sock.getInputStream();
                int num = 1000 + (int) (Math.random() * 100000);
                os.write(protoFrame("[" + (num++) + ",\"ah\",\"" + ver + "\",\"\",\"\",0,0]")); os.flush();
                protoRead(is, 2000);
                os.write(protoFrame("[" + num + ",\"ms\"]")); os.flush();
                o.put("raw", protoRead(is, 6000));
                o.put("ok", true);
            } catch (Throwable e) { o.put("ok", false); o.put("error", String.valueOf(e.getMessage())); }
            finally { try { if (sock != null) sock.close(); } catch (Exception ignored) {} }
            call.resolve(o);
        } }).start();
    }

    // ===== protoSearch =====
    // ПОИСК через служебный сервер официального клиента (команда rc) — вместо обхода страниц сайта
    @PluginMethod
    public void protoSearch(final PluginCall call) {
        final String host = call.getString("host", "app.4pda.to");
        final int port = call.getInt("port", 993);
        final String q = call.getString("query", "");
        final int from = call.getInt("from", 0);
        final int count = call.getInt("count", 60);
        final String ver = call.getString("ver", "1.9.43");
        final int waitMs = call.getInt("waitMs", 12000);
        new Thread(new Runnable() { public void run() {
            java.net.Socket sock = null; JSObject o = new JSObject(); long t0 = System.currentTimeMillis();
            try {
                sock = new java.net.Socket();
                sock.connect(new java.net.InetSocketAddress(host, port), 8000);
                sock.setSoTimeout(6000);
                java.io.OutputStream os = sock.getOutputStream();
                java.io.InputStream is = sock.getInputStream();
                int num = 1000 + (int) (Math.random() * 100000);
                os.write(protoFrame("[" + (num++) + ",\"ah\",\"" + ver + "\",\"\",\"\",0,0]")); os.flush();
                protoRead(is, 2000);
                String esc = q.replace("\\", "").replace("\"", "");
                int flags = call.getInt("flags", 196610);
                String sortA = call.getString("a", "[0]"), sortB = call.getString("b", "[0]"), sortC = call.getString("c", "[0]");
                os.write(protoFrame("[" + num + ",\"rc\"," + flags + "," + sortA + "," + sortB + "," + sortC + ",\"" + esc + "\"," + from + "," + count + "]")); os.flush();
                o.put("raw", protoRead(is, waitMs));
                o.put("ok", true);
            } catch (Throwable e) {
                o.put("ok", false); o.put("error", e.getClass().getSimpleName() + ": " + e.getMessage());
            } finally { try { if (sock != null) sock.close(); } catch (Exception ignored) {} }
            o.put("ms", System.currentTimeMillis() - t0);
            call.resolve(o);
        } }).start();
    }

    // ===== protoTopics =====
    // ПАЧКОЙ: одно соединение — представляемся и отправляем запросы ВСЕХ тем подряд,
    // не дожидаясь ответа на каждый. Ответы приходят вперемешку, сопоставляем их по номеру запроса.
    @PluginMethod
    public void protoTopics(final PluginCall call) {
        final String host = call.getString("host", "app.4pda.to");
        final int port = call.getInt("port", 993);
        final JSArray idsArr = call.getArray("topicIds");
        final int waitMs = call.getInt("waitMs", 20000);
        final String ver = call.getString("ver", "1.9.43");   // версия официального клиента — приходит из настроек, не зашита
        new Thread(new Runnable() { public void run() {
            java.net.Socket sock = null; JSObject o = new JSObject(); long t0 = System.currentTimeMillis();
            JSArray out = new JSArray();
            try {
                java.util.List<String> ids = new java.util.ArrayList<>();
                try { java.util.List<Object> l = idsArr != null ? idsArr.toList() : null; if (l != null) for (Object x : l) { String v = String.valueOf(x); if (v.matches("\\d{3,9}")) ids.add(v); } } catch (Exception ignored) {}
                if (ids.isEmpty()) { o.put("ok", true); o.put("items", out); call.resolve(o); return; }
                sock = new java.net.Socket();
                sock.connect(new java.net.InetSocketAddress(host, port), 8000);
                sock.setSoTimeout(4000);
                java.io.OutputStream os = sock.getOutputStream();
                java.io.InputStream is = sock.getInputStream();
                int num = 1000 + (int) (Math.random() * 100000);
                os.write(protoFrame("[" + (num++) + ",\"ah\",\"" + ver + "\",\"\",\"\",0,0]")); os.flush();
                o.put("hello", protoRead(is, 2500));
                java.util.HashMap<String, String> byNum = new java.util.HashMap<>();
                for (String id : ids) {
                    int n = num++;
                    byNum.put(String.valueOf(n), id);
                    os.write(protoFrame("[" + n + ",\"fr\"," + id + ",0,1,0]"));
                }
                os.flush();
                java.util.HashMap<String, String> got = new java.util.HashMap<>();
                java.io.ByteArrayOutputStream acc = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                while (got.size() < ids.size() && System.currentTimeMillis() - t0 < waitMs) {
                    int n;
                    try { n = is.read(buf); } catch (java.net.SocketTimeoutException te) { break; }
                    if (n <= 0) break;
                    acc.write(buf, 0, n);
                    byte[] b = acc.toByteArray();
                    int i = 0;
                    while (i + 2 <= b.length) {
                        int b0 = b[i] & 0xff, ln = b[i + 1] & 0x7f, p = i + 2;
                        if (ln == 126) { if (p + 2 > b.length) break; ln = ((b[p] & 0xff) << 8) | (b[p + 1] & 0xff); p += 2; }
                        else if (ln == 127) { if (p + 8 > b.length) break; ln = ((b[p + 4] & 0xff) << 24) | ((b[p + 5] & 0xff) << 16) | ((b[p + 6] & 0xff) << 8) | (b[p + 7] & 0xff); p += 8; }
                        if (p + ln > b.length) break;
                        String txt;
                        if ((b0 & 0x40) != 0 && ln > 4) {
                            try { java.util.zip.Inflater inf = new java.util.zip.Inflater(true);
                                  inf.setInput(b, p + 4, ln - 4);
                                  byte[] ob = new byte[262144]; int m = inf.inflate(ob); inf.end();
                                  txt = new String(ob, 0, m, "windows-1251"); }
                            catch (Throwable e) { txt = ""; }
                        } else txt = new String(b, p, ln, "windows-1251");
                        i = p + ln;
                        int c = txt.indexOf(',');
                        if (txt.startsWith("[") && c > 1) {
                            String key = txt.substring(1, c).trim();
                            String id = byNum.get(key);
                            if (id != null && !got.containsKey(id)) got.put(id, txt);
                        }
                    }
                    if (i > 0) { byte[] rest = new byte[b.length - i]; System.arraycopy(b, i, rest, 0, rest.length); acc.reset(); acc.write(rest); }
                }
                boolean brief = Boolean.TRUE.equals(call.getBoolean("brief", Boolean.FALSE));
                for (java.util.Map.Entry<String, String> e : got.entrySet()) {
                    JSObject it = new JSObject();
                    it.put("topicId", e.getKey());
                    String r = e.getValue();
                    if (brief) {   // разбираем здесь и отдаём только нужное — не гоняем шапку целиком в интерфейс
                        try {
                            java.util.regex.Matcher m1 = java.util.regex.Pattern.compile("attachment=\\\\?\"(\\d{4,12}):([^\"\\\\]+)").matcher(r);
                            while (m1.find()) {
                                String nm = m1.group(2);
                                if (nm.matches("(?i).+\\.(png|jpg|jpeg|gif|webp)")) { it.put("icon", "https://4pda.to/forum/index.php?act=attach&type=post&id=" + m1.group(1)); break; }   // путь для КАРТИНОК поста
                            }
                        } catch (Throwable ignored) {}
                        try {
                            java.util.regex.Matcher m2 = java.util.regex.Pattern.compile(",\\d{3,9},\"[^\"]{2,120}\",\"([^\"]{2,300})\"").matcher(r);
                            if (m2.find()) it.put("desc", m2.group(1).replaceAll("\\s+", " ").trim());
                        } catch (Throwable ignored) {}
                        try {
                            java.util.regex.Matcher m3 = java.util.regex.Pattern.compile("\\[\\[1,(\\d{2,6}),\"").matcher(r);
                            if (m3.find()) it.put("forumId", Integer.parseInt(m3.group(1)));
                        } catch (Throwable ignored) {}
                        if (!it.has("icon")) {   // запасной путь: иконка вставлена обычной картинкой
                            try {
                                java.util.regex.Matcher mi = java.util.regex.Pattern.compile("(https?://[^\\s\"'\\[\\]]+\\.(?i:png|jpe?g|gif|webp))").matcher(r);
                                if (mi.find()) it.put("icon", mi.group(1));
                            } catch (Throwable ignored) {}
                        }
                        if (!it.has("icon")) it.put("raw", r.length() > 6000 ? r.substring(0, 6000) : r);   // не нашли — отдаём кусок шапки, разберёт интерфейс
                    } else it.put("raw", r.length() > 20000 ? r.substring(0, 20000) : r);
                    out.put(it);
                }
                o.put("ok", true);
            } catch (Throwable e) {
                o.put("ok", false); o.put("error", e.getClass().getSimpleName() + ": " + e.getMessage());
            } finally { try { if (sock != null) sock.close(); } catch (Exception ignored) {} }
            o.put("items", out); o.put("ms", System.currentTimeMillis() - t0);
            call.resolve(o);
        } }).start();
    }

    // ===== protoTopic =====
    // Запрос темы через служебный сервер официального клиента: представляемся («ah»),
    // затем просим тему («fr», номер темы) и возвращаем распакованный ответ (строки в windows-1251).
    @PluginMethod
    public void protoTopic(final PluginCall call) {
        final String host = call.getString("host", "app.4pda.to");
        final int port = call.getInt("port", 993);
        final String topicId = call.getString("topicId", "");
        final int waitMs = call.getInt("waitMs", 8000);
        final String ver = call.getString("ver", "1.9.43");
        new Thread(new Runnable() { public void run() {
            java.net.Socket sock = null; JSObject o = new JSObject(); long t0 = System.currentTimeMillis();
            try {
                sock = new java.net.Socket();
                sock.connect(new java.net.InetSocketAddress(host, port), 8000);
                sock.setSoTimeout(waitMs);
                java.io.OutputStream os = sock.getOutputStream();
                java.io.InputStream is = sock.getInputStream();
                int num = 1000 + (int) (Math.random() * 100000);
                os.write(protoFrame("[" + num + ",\"ah\",\"" + ver + "\",\"\",\"\",0,0]")); os.flush();
                String r1 = protoRead(is, 2500);
                o.put("hello", r1);
                os.write(protoFrame("[" + (num + 1) + ",\"fr\"," + topicId + ",0,20,0]")); os.flush();
                String r2 = protoRead(is, waitMs);
                o.put("topic", r2);
                o.put("ok", true); o.put("ms", System.currentTimeMillis() - t0);
            } catch (Throwable e) {
                o.put("ok", false); o.put("error", e.getClass().getSimpleName() + ": " + e.getMessage()); o.put("ms", System.currentTimeMillis() - t0);
            } finally { try { if (sock != null) sock.close(); } catch (Exception ignored) {} }
            call.resolve(o);
        } }).start();
    }

    // ===== wsProbe =====
    // Полное подключение как у официального клиента: сначала веб-сокет-рукопожатие
    // (GET /ws/ + Upgrade + Sec-WebSocket-Protocol: app + версия 13), затем кадр с данными.
    @PluginMethod
    public void wsProbe(final PluginCall call) {
        final String host = call.getString("host", "app.4pda.ru");
        final int port = call.getInt("port", 443);
        final String path = call.getString("path", "/ws/");
        final int type = call.getInt("type", 1) & 0xf;
        final boolean compress = !Boolean.FALSE.equals(call.getBoolean("compress", true));
        final boolean mask = !Boolean.FALSE.equals(call.getBoolean("mask", false));
        final String text = call.getString("text", "");
        final int waitMs = call.getInt("waitMs", 6000);
        final boolean tls = !Boolean.FALSE.equals(call.getBoolean("tls", true));   // на нестандартных портах бывает без шифрования
        new Thread(new Runnable() { public void run() {
            java.net.Socket sock = null; JSObject o = new JSObject(); long t0 = System.currentTimeMillis();
            try {
                if (tls) { sock = javax.net.ssl.SSLSocketFactory.getDefault().createSocket(host, port); }   // с именем хоста (SNI)
                else { sock = new java.net.Socket(); sock.connect(new java.net.InetSocketAddress(host, port), 8000); }
                sock.setSoTimeout(waitMs);
                if (tls) ((javax.net.ssl.SSLSocket) sock).startHandshake();
                byte[] keyb = new byte[16]; new java.util.Random().nextBytes(keyb);
                String key = Base64.encodeToString(keyb, Base64.NO_WRAP);
                String hs = "GET " + path + " HTTP/1.1\r\nHost: " + host + "\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                        + "Sec-WebSocket-Key: " + key + "\r\nSec-WebSocket-Protocol: app\r\nSec-WebSocket-Version: 13\r\n\r\n";
                java.io.OutputStream os = sock.getOutputStream();
                os.write(hs.getBytes(java.nio.charset.StandardCharsets.ISO_8859_1)); os.flush();
                java.io.InputStream is = sock.getInputStream();
                java.io.ByteArrayOutputStream head = new java.io.ByteArrayOutputStream();
                int c; boolean upgraded = false;
                while ((c = is.read()) >= 0) {
                    head.write(c);
                    String h = head.toString("ISO-8859-1");
                    if (h.endsWith("\r\n\r\n")) { upgraded = h.contains(" 101 "); break; }
                    if (head.size() > 4096) break;
                }
                o.put("handshake", head.toString("ISO-8859-1"));
                o.put("upgraded", upgraded);
                if (upgraded && text != null) {
                    byte[] raw = text.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                    byte[] body; int lenField;
                    if (compress) {
                        java.util.zip.Deflater df = new java.util.zip.Deflater(6, true);
                        df.setInput(raw); df.finish();
                        byte[] tmp = new byte[raw.length + 100]; int n = df.deflate(tmp); df.end();
                        body = new byte[n]; System.arraycopy(tmp, 0, body, 0, n); lenField = n + 4;
                    } else { body = raw; lenField = raw.length; }
                    java.io.ByteArrayOutputStream fr = new java.io.ByteArrayOutputStream();
                    fr.write(0x80 | (compress ? 0x40 : 0) | type);
                    int lb = mask ? 0x80 : 0;
                    if (lenField <= 0x7d) fr.write(lb | lenField);
                    else if (lenField <= 0xffff) { fr.write(lb | 0x7e); fr.write((lenField >> 8) & 0xff); fr.write(lenField & 0xff); }
                    else { fr.write(lb | 0x7f); for (int i = 0; i < 4; i++) fr.write(0);
                           fr.write((lenField >> 24) & 0xff); fr.write((lenField >> 16) & 0xff); fr.write((lenField >> 8) & 0xff); fr.write(lenField & 0xff); }
                    byte[] pre = compress ? new byte[]{ (byte) (raw.length & 0xff), (byte) ((raw.length >> 8) & 0xff), (byte) ((raw.length >> 16) & 0xff), (byte) ((raw.length >> 24) & 0xff) } : new byte[0];
                    byte[] payload = new byte[pre.length + body.length];
                    System.arraycopy(pre, 0, payload, 0, pre.length); System.arraycopy(body, 0, payload, pre.length, body.length);
                    if (mask) {
                        byte[] mk = new byte[4]; new java.util.Random().nextBytes(mk); fr.write(mk, 0, 4);
                        for (int i = 0; i < payload.length; i++) payload[i] = (byte) (payload[i] ^ mk[i & 3]);
                    }
                    fr.write(payload, 0, payload.length);
                    os.write(fr.toByteArray()); os.flush();
                    o.put("sent", fr.size());
                    java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                    byte[] buf = new byte[2048];
                    try { int n; while (bos.size() < 8192 && (n = is.read(buf)) > 0) { bos.write(buf, 0, n); if (System.currentTimeMillis() - t0 > waitMs) break; } }
                    catch (java.net.SocketTimeoutException ignored) {}
                    byte[] resp = bos.toByteArray();
                    StringBuilder hx = new StringBuilder(); StringBuilder pr = new StringBuilder();
                    for (int i = 0; i < resp.length; i++) { hx.append(String.format("%02x", resp[i] & 0xff)); if ((i & 1) == 1) hx.append(' ');
                        int ch = resp[i] & 0xff; pr.append(ch >= 32 && ch < 127 ? (char) ch : '.'); }
                    o.put("len", resp.length); o.put("hex", hx.toString()); o.put("text", pr.toString());
                    try {
                        if (resp.length > 2) {
                            int f = resp[0] & 0xff, p = 1, dlen = resp[1] & 0x7f;
                            if (dlen == 0x7e) { dlen = ((resp[2] & 0xff) << 8) | (resp[3] & 0xff); p = 4; }
                            else if (dlen == 0x7f) { dlen = ((resp[6] & 0xff) << 24) | ((resp[7] & 0xff) << 16) | ((resp[8] & 0xff) << 8) | (resp[9] & 0xff); p = 10; }
                            else p = 2;
                            o.put("respType", f & 0xf); o.put("respCompressed", (f & 0x40) != 0); o.put("respLen", dlen);
                            if ((f & 0x40) != 0 && resp.length > p + 4) {
                                java.util.zip.Inflater inf = new java.util.zip.Inflater(true);
                                inf.setInput(resp, p + 4, resp.length - p - 4);
                                byte[] out = new byte[65536]; int m = inf.inflate(out); inf.end();
                                o.put("body", new String(out, 0, m, java.nio.charset.StandardCharsets.UTF_8));
                            } else if (resp.length > p) o.put("body", new String(resp, p, Math.min(resp.length - p, 4096), java.nio.charset.StandardCharsets.UTF_8));
                        }
                    } catch (Throwable ignored) {}
                }
                o.put("ms", System.currentTimeMillis() - t0); o.put("ok", true);
            } catch (Throwable e) {
                o.put("ok", false); o.put("error", e.getClass().getSimpleName() + ": " + e.getMessage()); o.put("ms", System.currentTimeMillis() - t0);
            } finally { try { if (sock != null) sock.close(); } catch (Exception ignored) {} }
            call.resolve(o);
        } }).start();
    }

    // ===== sendFrame =====
    // Отправка пакета В ТОЧНОСТИ как это делает официальный клиент 4pda:
    // байт0 = флаги(0x80 ответ ждём / 0x40 сжато) | тип(младшие 4 бита);
    // байт1 = длина (<=125 как есть; <=65535 — 0x7e + 2 байта; иначе 0x7f + 8 байт),
    // при сжатии сразу после заголовка идут 4 байта исходной длины (младшим байтом вперёд),
    // дальше сжатые данные (deflate без заголовка zlib, уровень 6). Ответ разбираем так же.
    @PluginMethod
    public void sendFrame(final PluginCall call) {
        final String host = call.getString("host", "app.4pda.ru");
        final int port = call.getInt("port", 443);
        final int type = call.getInt("type", 1) & 0xf;
        final boolean compress = !Boolean.FALSE.equals(call.getBoolean("compress", true));
        final boolean flag80 = !Boolean.FALSE.equals(call.getBoolean("flag80", true));
        final String text = call.getString("text", "");
        final int waitMs = call.getInt("waitMs", 6000);
        final boolean tls = !Boolean.FALSE.equals(call.getBoolean("tls", true));   // на порту 993 у них без шифрования
        new Thread(new Runnable() { public void run() {
            java.net.Socket sock = null; JSObject o = new JSObject(); long t0 = System.currentTimeMillis();
            try {
                byte[] raw = text.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                byte[] body; int lenField;
                if (compress) {
                    java.util.zip.Deflater df = new java.util.zip.Deflater(6, true);
                    df.setInput(raw); df.finish();
                    byte[] tmp = new byte[raw.length + 100];
                    int n = df.deflate(tmp); df.end();
                    body = new byte[n]; System.arraycopy(tmp, 0, body, 0, n);
                    lenField = n + 4;
                } else { body = raw; lenField = raw.length; }
                java.io.ByteArrayOutputStream hdr = new java.io.ByteArrayOutputStream();
                int b0 = (flag80 ? 0x80 : 0) | (compress ? 0x40 : 0) | type;
                hdr.write(b0);
                if (lenField <= 0x7d) hdr.write(lenField);
                else if (lenField <= 0xffff) { hdr.write(0x7e); hdr.write((lenField >> 8) & 0xff); hdr.write(lenField & 0xff); }
                else { hdr.write(0x7f); hdr.write(0); hdr.write(0); hdr.write(0); hdr.write(0);
                       hdr.write((lenField >> 24) & 0xff); hdr.write((lenField >> 16) & 0xff); hdr.write((lenField >> 8) & 0xff); hdr.write(lenField & 0xff); }
                if (compress) { hdr.write(raw.length & 0xff); hdr.write((raw.length >> 8) & 0xff); hdr.write((raw.length >> 16) & 0xff); hdr.write((raw.length >> 24) & 0xff); }
                if (tls) { sock = javax.net.ssl.SSLSocketFactory.getDefault().createSocket(host, port); }   // с именем хоста — иначе сервер закрывает связь
                else { sock = new java.net.Socket(); sock.connect(new java.net.InetSocketAddress(host, port), 8000); }
                sock.setSoTimeout(waitMs);
                if (tls) ((javax.net.ssl.SSLSocket) sock).startHandshake();
                int listenMs = call.getInt("listenMs", 3000);
                if (listenMs > 0) {   // слушаем приветствие сервера ДО отправки
                    sock.setSoTimeout(listenMs);
                    java.io.ByteArrayOutputStream hi = new java.io.ByteArrayOutputStream();
                    try { byte[] hb = new byte[1024]; int n; long h0 = System.currentTimeMillis();
                        while (hi.size() < 2048 && (n = sock.getInputStream().read(hb)) > 0) { hi.write(hb, 0, n); if (System.currentTimeMillis() - h0 > listenMs) break; } }
                    catch (java.net.SocketTimeoutException ignored) {}
                    byte[] hb2 = hi.toByteArray();
                    StringBuilder hh = new StringBuilder(), hp = new StringBuilder();
                    for (int i = 0; i < hb2.length; i++) { hh.append(String.format("%02x", hb2[i] & 0xff)); if ((i & 1) == 1) hh.append(' ');
                        int ch = hb2[i] & 0xff; hp.append(ch >= 32 && ch < 127 ? (char) ch : '.'); }
                    o.put("helloLen", hb2.length); o.put("helloHex", hh.toString()); o.put("helloText", hp.toString());
                    sock.setSoTimeout(waitMs);
                }
                sock.getOutputStream().write(hdr.toByteArray());
                if (body.length > 0) sock.getOutputStream().write(body);
                sock.getOutputStream().flush();
                o.put("sent", hdr.size() + body.length);
                java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[2048];
                try { int n; while (bos.size() < 8192 && (n = sock.getInputStream().read(buf)) > 0) { bos.write(buf, 0, n); if (System.currentTimeMillis() - t0 > waitMs) break; } }
                catch (java.net.SocketTimeoutException ignored) {}
                byte[] resp = bos.toByteArray();
                StringBuilder hx = new StringBuilder(); StringBuilder pr = new StringBuilder();
                for (int i = 0; i < resp.length; i++) { hx.append(String.format("%02x", resp[i] & 0xff)); if ((i & 1) == 1) hx.append(' ');
                    int c = resp[i] & 0xff; pr.append(c >= 32 && c < 127 ? (char) c : '.'); }
                o.put("len", resp.length); o.put("hex", hx.toString()); o.put("text", pr.toString());
                // пробуем разобрать ответ тем же форматом
                try {
                    if (resp.length > 2) {
                        int f = resp[0] & 0xff, p = 1, dlen = resp[1] & 0xff;
                        if (dlen == 0x7e) { dlen = ((resp[2] & 0xff) << 8) | (resp[3] & 0xff); p = 4; }
                        else if (dlen == 0x7f) { dlen = ((resp[6] & 0xff) << 24) | ((resp[7] & 0xff) << 16) | ((resp[8] & 0xff) << 8) | (resp[9] & 0xff); p = 10; }
                        else p = 2;
                        o.put("respType", f & 0xf); o.put("respCompressed", (f & 0x40) != 0); o.put("respLen", dlen);
                        if ((f & 0x40) != 0 && resp.length > p + 4) {
                            int orig = (resp[p] & 0xff) | ((resp[p + 1] & 0xff) << 8) | ((resp[p + 2] & 0xff) << 16) | ((resp[p + 3] & 0xff) << 24);
                            java.util.zip.Inflater inf = new java.util.zip.Inflater(true);
                            inf.setInput(resp, p + 4, resp.length - p - 4);
                            byte[] out = new byte[Math.max(16, Math.min(orig > 0 ? orig : 8192, 65536))];
                            int m = inf.inflate(out); inf.end();
                            o.put("body", new String(out, 0, m, java.nio.charset.StandardCharsets.UTF_8));
                        } else if (resp.length > p) {
                            o.put("body", new String(resp, p, Math.min(resp.length - p, 4096), java.nio.charset.StandardCharsets.UTF_8));
                        }
                    }
                } catch (Throwable ignored) {}
                o.put("ms", System.currentTimeMillis() - t0); o.put("ok", true);
            } catch (Throwable e) {
                o.put("ok", false); o.put("error", e.getClass().getSimpleName() + ": " + e.getMessage()); o.put("ms", System.currentTimeMillis() - t0);
            } finally { try { if (sock != null) sock.close(); } catch (Exception ignored) {} }
            call.resolve(o);
        } }).start();
    }

    // ===== rawSocket =====
    // ---- Отладка протокола официального клиента 4pda ----
    // Открывает обычное защищённое соединение с их сервером, шлёт заданные байты и возвращает ответ
    // в двух видах: шестнадцатеричном и печатном. Нужно, чтобы вслепую подобрать формат пакета.
    @PluginMethod
    public void rawSocket(final PluginCall call) {
        final String host = call.getString("host", "app.4pda.ru");
        final int port = call.getInt("port", 443);
        final boolean tls = !Boolean.FALSE.equals(call.getBoolean("tls", true));
        final String hex = call.getString("hex", "");
        final String text = call.getString("text", "");
        final int waitMs = call.getInt("waitMs", 5000);
        final int maxRead = call.getInt("maxRead", 4096);
        new Thread(new Runnable() { public void run() {
            java.net.Socket sock = null;
            JSObject o = new JSObject();
            long t0 = System.currentTimeMillis();
            try {
                sock = tls ? javax.net.ssl.SSLSocketFactory.getDefault().createSocket() : new java.net.Socket();
                sock.connect(new java.net.InetSocketAddress(host, port), 8000);
                sock.setSoTimeout(waitMs);
                if (sock instanceof javax.net.ssl.SSLSocket) ((javax.net.ssl.SSLSocket) sock).startHandshake();
                o.put("connected", true);
                byte[] data;
                if (hex != null && !hex.isEmpty()) {
                    String h = hex.replaceAll("[^0-9a-fA-F]", "");
                    data = new byte[h.length() / 2];
                    for (int i = 0; i < data.length; i++) data[i] = (byte) Integer.parseInt(h.substring(i * 2, i * 2 + 2), 16);
                } else data = (text == null ? "" : text).getBytes(java.nio.charset.StandardCharsets.UTF_8);
                if (data.length > 0) { sock.getOutputStream().write(data); sock.getOutputStream().flush(); }
                o.put("sent", data.length);
                java.io.InputStream is = sock.getInputStream();
                java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[2048];
                try {
                    int n;
                    while (bos.size() < maxRead && (n = is.read(buf)) > 0) {
                        bos.write(buf, 0, n);
                        if (System.currentTimeMillis() - t0 > waitMs) break;
                    }
                } catch (java.net.SocketTimeoutException ignored) {}
                byte[] resp = bos.toByteArray();
                StringBuilder hx = new StringBuilder(); StringBuilder pr = new StringBuilder();
                for (int i = 0; i < resp.length; i++) {
                    hx.append(String.format("%02x", resp[i] & 0xff)); if ((i & 1) == 1) hx.append(' ');
                    int c = resp[i] & 0xff; pr.append(c >= 32 && c < 127 ? (char) c : '.');
                }
                o.put("len", resp.length);
                o.put("hex", hx.toString());
                o.put("text", pr.toString());
                o.put("ms", System.currentTimeMillis() - t0);
                o.put("ok", true);
            } catch (Throwable e) {
                o.put("ok", false);
                o.put("error", String.valueOf(e.getClass().getSimpleName()) + ": " + String.valueOf(e.getMessage()));
                o.put("ms", System.currentTimeMillis() - t0);
            } finally { try { if (sock != null) sock.close(); } catch (Exception ignored) {} }
            call.resolve(o);
        } }).start();
    }

    // ===== protoFrame =====
    private byte[] protoFrame(String text) throws Exception {
        byte[] raw = text.getBytes("windows-1251");
        java.util.zip.Deflater df = new java.util.zip.Deflater(6, true);
        df.setInput(raw); df.finish();
        byte[] tmp = new byte[raw.length + 100]; int n = df.deflate(tmp); df.end();
        int lenField = n + 4;
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        out.write(0xc1);
        if (lenField <= 0x7d) out.write(lenField);
        else if (lenField <= 0xffff) { out.write(0x7e); out.write((lenField >> 8) & 0xff); out.write(lenField & 0xff); }
        else { out.write(0x7f); for (int i = 0; i < 4; i++) out.write(0);
               out.write((lenField >> 24) & 0xff); out.write((lenField >> 16) & 0xff); out.write((lenField >> 8) & 0xff); out.write(lenField & 0xff); }
        out.write(raw.length & 0xff); out.write((raw.length >> 8) & 0xff); out.write((raw.length >> 16) & 0xff); out.write((raw.length >> 24) & 0xff);
        out.write(tmp, 0, n);
        return out.toByteArray();
    }

    // ===== protoRead =====
    private String protoRead(java.io.InputStream is, int waitMs) {
        try {
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[4096]; long t0 = System.currentTimeMillis();
            while (bos.size() < 262144) {
                int n;
                try { n = is.read(buf); } catch (java.net.SocketTimeoutException te) { break; }
                if (n <= 0) break;
                bos.write(buf, 0, n);
                if (System.currentTimeMillis() - t0 > waitMs) break;
                if (is.available() == 0) { try { Thread.sleep(250); } catch (InterruptedException ignored) {} if (is.available() == 0) break; }
            }
            byte[] b = bos.toByteArray();
            StringBuilder sb = new StringBuilder();
            int i = 0;
            while (i + 2 <= b.length) {
                int b0 = b[i] & 0xff, ln = b[i + 1] & 0x7f, p = i + 2;
                if (ln == 126) { ln = ((b[p] & 0xff) << 8) | (b[p + 1] & 0xff); p += 2; }
                else if (ln == 127) { ln = ((b[p + 4] & 0xff) << 24) | ((b[p + 5] & 0xff) << 16) | ((b[p + 6] & 0xff) << 8) | (b[p + 7] & 0xff); p += 8; }
                if (p + ln > b.length) break;
                byte[] pay = new byte[ln]; System.arraycopy(b, p, pay, 0, ln); i = p + ln;
                if ((b0 & 0x40) != 0 && ln > 4) {
                    try {
                        java.util.zip.Inflater inf = new java.util.zip.Inflater(true);
                        inf.setInput(pay, 4, ln - 4);
                        byte[] out = new byte[262144]; int m = inf.inflate(out); inf.end();
                        sb.append(new String(out, 0, m, "windows-1251"));
                    } catch (Throwable e) { sb.append("<не распаковалось>"); }
                } else sb.append(new String(pay, "windows-1251"));
                sb.append("\n");
            }
            return sb.toString();
        } catch (Throwable e) { return "<ошибка чтения: " + e.getMessage() + ">"; }
    }

    // ===== md5hex =====
    private String md5hex(String in) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            byte[] d = md.digest(in.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b & 0xff));
            return sb.toString();
        } catch (Throwable e) { return ""; }
    }

    // ===== agIdBase =====
    // ===== идентификатор устройства для сервера App&Game — РОВНО как q()/device_info у ag4pda =====
    private String agIdBase() {
        try {   // WiFi mac (до 6.0 доступен) — как первая ветка q()
            if (android.os.Build.VERSION.SDK_INT < 23) {
                android.net.wifi.WifiManager wm = (android.net.wifi.WifiManager) getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                if (wm != null && wm.getConnectionInfo() != null) { String m = wm.getConnectionInfo().getMacAddress(); if (m != null && m.length() > 0 && !"null".equals(m)) return "WiFi|" + m; }
            }
        } catch (Throwable ignored) {}
        try {   // сумма hashCode полей Build — основная ветка на современных телефонах
            int hc = android.os.Build.BOARD.hashCode() + android.os.Build.BRAND.hashCode() + android.os.Build.CPU_ABI.hashCode() + android.os.Build.DEVICE.hashCode() + android.os.Build.DISPLAY.hashCode() + android.os.Build.HOST.hashCode() + android.os.Build.ID.hashCode() + android.os.Build.MANUFACTURER.hashCode() + android.os.Build.MODEL.hashCode() + android.os.Build.PRODUCT.hashCode() + android.os.Build.TAGS.hashCode() + android.os.Build.TYPE.hashCode() + android.os.Build.USER.hashCode();
            if (hc != 0) return "Build|" + hc;
        } catch (Throwable ignored) {}
        try { String ser = android.os.Build.SERIAL; if (ser != null && !"unknown".equals(ser)) return "No|" + ser; } catch (Throwable ignored) {}
        try { return "ID|" + android.provider.Settings.Secure.getString(getContext().getContentResolver(), android.provider.Settings.Secure.ANDROID_ID); } catch (Throwable ignored) {}
        return "";
    }

    // ===== agUuid =====
    private String agUuid() {   // стойкий случайный UUID, как X() у ag4pda (хранится в отдельных настройках)
        try {
            android.content.SharedPreferences sp = getContext().getSharedPreferences("device_id", Context.MODE_PRIVATE);
            String v = sp.getString("device_id", null);
            if (v == null) { v = java.util.UUID.randomUUID().toString(); sp.edit().putString("device_id", v).apply(); }
            return v;
        } catch (Throwable e) { return ""; }
    }

    // ===== agModelName =====
    private String agModelName() {   // как s(): "Производитель Модель", без дублей
        String mf = android.os.Build.MANUFACTURER == null ? "" : android.os.Build.MANUFACTURER;
        String md = android.os.Build.MODEL == null ? "" : android.os.Build.MODEL;
        String r = md.startsWith(mf) ? md : (mf + " " + md);
        return r.length() > 0 ? Character.toUpperCase(r.charAt(0)) + r.substring(1) : r;
    }

    // ===== agAbiMask =====
    private int agAbiMask() {   // как l.a.c(): битовая маска процессоров устройства
        int i = 0;
        String[] abis = (android.os.Build.VERSION.SDK_INT >= 21) ? android.os.Build.SUPPORTED_ABIS : new String[]{ android.os.Build.CPU_ABI, android.os.Build.CPU_ABI2 };
        if (abis != null) for (String a : abis) {
            if (a == null || a.isEmpty()) continue;
            if (a.startsWith("armeabi")) i |= 512;
            if (a.equals("armeabi")) i |= 2048;
            if (a.equals("armeabi-v7a")) i |= 4096;
            if (a.equals("arm64-v8a")) i |= 65536;
            if (a.equals("x86")) i |= 8192;
            if (a.equals("x86_64")) i |= 32768;
            if (a.equals("mips")) i |= 16384;
            if (a.equals("mips64")) i |= 131072;
        }
        return i;
    }

    // ===== agTzMinutes =====
    private int agTzMinutes() {   // как l.d.x(): смещение часового пояса в минутах
        try { java.util.GregorianCalendar g = new java.util.GregorianCalendar(); return -(g.get(java.util.Calendar.ZONE_OFFSET) + g.get(java.util.Calendar.DST_OFFSET)) / 60000; } catch (Throwable e) { return 0; }
    }

    // ===== drawableToBase64 =====
    // ---- иконки → data:image/png;base64 (уменьшаем до 144px) ----
    private String drawableToBase64(Drawable d) {
        Bitmap b = drawableToBitmap(d);
        if (b == null) return null;
        int mx = Math.max(b.getWidth(), b.getHeight());
        if (mx > 96) {
            float sc = 96f / mx;
            b = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * sc)), Math.max(1, Math.round(b.getHeight() * sc)), true);
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.PNG, 100, out);
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }


    // ===== drawableToBitmap =====
    private Bitmap drawableToBitmap(Drawable d) {
        if (d == null) return null;
        try {
            if (d instanceof android.graphics.drawable.BitmapDrawable) {
                Bitmap bm = ((android.graphics.drawable.BitmapDrawable) d).getBitmap();
                if (bm != null) return bm;
            }
        } catch (Exception ignored) {}
        int w = d.getIntrinsicWidth(), h = d.getIntrinsicHeight();
        if (w <= 0 || h <= 0) { w = 144; h = 144; }
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        d.setBounds(0, 0, w, h);
        d.draw(c);
        return b;
    }
}
